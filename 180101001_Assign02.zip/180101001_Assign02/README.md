Name : Aarti Meena
Roll number : 180101001
programming language used : c



HOW TO RUN AND COMPILE:
1. gcc -o minishell minishell.c
2. ./minishell


