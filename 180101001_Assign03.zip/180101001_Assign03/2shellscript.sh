
tar -xzvf tarfile.tar.gz  #for tar.bz2 or bzip use -xjvf tar.bz2
#extract to specific path -C path
tar -xzvf tarfile.tar.gz -C /mypath
#extract a single file ; just add the name of the file and the path after the command
tar -xzv -f file.tar.gz "./new/abc.text"
#extract multiple files
tar -xzv -f file.tar.gz "./new/abc.text" "./new/xyz.txt"
#extract multiple files using *
tar -xzv -f file.tar.gz --wildcards "*.txt"
#List content of tar archive -t list content  without extracting
tar -tzv -f abc.tar.gz  #this can be done also with $ vim abc.tar.gz
#List pipe output with grep ; search FILES with a given name
tar -tzv -f file.tar.gz |grep abc.txt
#search in a archive without extraction ; -O extract to standard output; you can't normally
#search  string with grep in an compressed archive
tar xvf  test.tar -O | grep "pattern"
#create tar/tar.gz archive ; creates tar arhcive using a directory and add the files in it and subdirs also
#IS NOT COMPRESSED, just tarred
tar -cvf abc.tar ./new/
#like .18 but with compression
tar -czvf abc.tar ./new/  # or -cjvf
#ask confirmation before addding to archive
#-w ask for every file before adding ; if you dont enter something is No (not adding)
tar -czw -f abc.tar.gz ./new/*
#list the files in the archive -t
tar -t -f abc.tar.gz
#adding files to existent archive -r adding file but NOT TO COMPRESSED archive; see next command for trick
tar -rv -f abc.tar abc.txt
#a trick for adding files to to a compressed archive using gunzip, which decompress,add files and compress
gunzip archive tar.gz
tar -rf archive.tar ./path/file
gzip archive.tar
#backup directories, maybe with cron with today signature like archive-20160318.tar.gz' 
tar -czv -f archive-$(date +%Y%m%d).tar.gz ./new/

