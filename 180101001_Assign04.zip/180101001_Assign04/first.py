print("\n                        TIC TAC TOE          \n\n")
print(20*' ','  1  | 2  | 3    ')
print(20*' ',"-----+----+----- ")
print(20*' ',"     |    |      ")
print(20*' ',"  4  | 5  | 6    ")
print(20*' ',"-----+----+----- ")
print(20*' ',"     |    |      ")
print(20*' ',"  7  | 8  | 9    \n")


def displayboard():
    print()
    print('                               reference:')
    print('     |    |     ',10*' ','     |    |   ',)
    print('  '+board[1]+'  | '+board[2]+'  | '+board[3]+'   ',10*' ','  1  | 2  | 3  ')
    print('-----+----+-----',10*' ',"-----+----+-----")
    print('     |    |     ',10*' ',"     |    |     ")
    print('  '+board[4]+'  | '+board[5]+'  | '+board[6]+'   ',10*' ',"  4  | 5  | 6   ")
    print('-----+----+-----',10*' ',"-----+----+-----")
    print('     |    |     ',10*' ',"     |    |      ")
    print('  '+board[7]+'  | '+board[8]+'  | '+board[9]+'   ',10*' ',"  7  | 8  | 9    \n\n")


def userinput(mark):
    while True:
        inp = input(f"[USER] '{mark}' Enter your choice:")
        if inp.isdigit() and int(inp) <10 and int(inp) >0:
            inp = int(inp)
            if board[inp] == " ":
                return inp
            else:
                print(f"[USER] '{mark}' place already taken.")
        else:
            print(f"[USER] '{mark}' Enter valid option (1 - 9).")


def winning(mark,board):
    winningplace = [[1,2,3],[4,5,6],[7,8,9],[1,4,7],[2,5,8],[3,6,9],[1,5,9],[3,5,7]]
    for winplace in winningplace:
        if board[winplace[0]] == board[winplace[1]] == board[winplace[2]] == mark:
            return True


def winmove(i,board,mark):
    tempboard = list(board)
    tempboard[i] = mark
    if winning(mark,tempboard):
        return True
    else:
        return False


def computerinput(computer , user , board):
    for i in range(1,10):
        if board[i] == ' ' and winmove(i,board,computer):
            return i
    for i in range(1,10):
        if board[i] == ' ' and winmove(i,board,user):
            return i
    for i in [5,1,7,3,2,9,8,6,4]:
        if board[i] == ' ':
            return i

def newgame():
    while True:
        nxt = input('[USER] Do you want to play again?(y/n):')
        if nxt in['y','Y']:
            again = True
            break
        elif nxt in ['n','N']:
            print('Have a great day')
            again = False
            break
        else:
            print('Enter correct input')
    if again:
        print('__________NEW GAME__________')
        game()
    else:
        return False

 
def wincheck(user , computer):
    winningplace = [[1,2,3],[4,5,6],[7,8,9],[1,4,7],[2,5,8],[3,6,9],[1,5,9],[3,5,7]]
    for winplace in winningplace:
        if board[winplace[0]] == board[winplace[1]] == board[winplace[2]] == user:
            print('[USER] wins the match!')
            if not newgame():
                return False
        elif board[winplace[0]] == board[winplace[1]] == board[winplace[2]] == computer:
                print('[COMPUTER] wins the match!')
                if not newgame():
                    return False
    if ' ' not in board:
        print('MATCH DRAW!!')
        if not newgame():
            return False
    return True


def userchoice():
    while True:
        inp = input('[USER]Choose your mark[x/o]: ')
        if inp in ['x' , 'X']:
            print('[USER]You choose "X".\n[USER]You play first.')
            return 'x','o'
        elif inp in ['O','o']:
            print('[USER] You choose "O".\n[USER] Computer plays first.')
            return 'o','x'
        else:
            print('[USER] Enter correct input!')


def game():
    global board
    play = True
    board =['',' ',' ',' ',' ',' ',' ',' ',' ',' ']
    user , computer = userchoice()
    displayboard()
    while play:
        if user == 'x':
            x = userinput(user)
            board[x] = user
            displayboard()
            play = wincheck(user , computer)
            if play:
                o = computerinput(computer , user , board)
                print(f'[COMPUTER] Entered:{o}')
                board[o] = computer
                displayboard()
                play = wincheck(user, computer)
        else:
            x = computerinput(computer , user , board)
            print(f'[COMPUTER] Entered:{x}')
            board[x] = computer
            displayboard()
            play = wincheck(user , computer)
            if play:
                o = userinput(user)
                board[o] = user
                displayboard()
                play = wincheck(user , computer)

           
if __name__ == '__main__':
    game()
    
